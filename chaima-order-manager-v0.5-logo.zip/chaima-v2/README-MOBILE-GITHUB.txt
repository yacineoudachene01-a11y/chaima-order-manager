CHAIMA ORDER MANAGER v0.3.0

ارفع محتويات مجلد المشروع إلى جذر مستودع GitHub، وليس ملف ZIP فقط. حافظ على المسار .github/workflows/build-android.yml.

بعد الرفع افتح Actions وانتظر Build Chaima Android APK. عند النجاح افتح تفاصيل التشغيل ثم Artifacts لتحميل ملف APK.

هذه نسخة تجريبية: لا يوجد ربط فعلي مع Shopify أو ZR.express أو خدمات الرسائل حتى الآن.
