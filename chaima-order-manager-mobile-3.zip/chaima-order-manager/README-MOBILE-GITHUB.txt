CHAIMA ORDER MANAGER — BUILD APK USING YOUR PHONE

1) On GitHub, create a NEW repository named chaima-order-manager.
2) Choose Public or Private, then create it.
3) In the repository, tap Add file > Upload files.
4) Upload this ZIP file to the repository root (do not extract it).
5) Commit the upload.
6) Open Actions tab. Allow GitHub Actions if asked.
7) Open workflow “Build Android APK” and wait until it finishes green.
8) Open the successful workflow run, scroll to Artifacts, download
   chaima-order-manager-debug-apk, extract the downloaded artifact ZIP,
   then install app-debug.apk on your Android phone.

If workflow did not start automatically: Actions > Build Android APK > Run workflow.

IMPORTANT:
- This is a TEST APK with demo data only.
- Shopify, ZRexpress, SMS, WhatsApp and cloud database are not connected yet.
- Never put API keys, passwords, or private tokens in GitHub files.
